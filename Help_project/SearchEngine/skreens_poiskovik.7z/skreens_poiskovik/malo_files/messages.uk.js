(function(Lego){
if (!Lego) Lego = window.Lego = {};

Lego.messages = {
    'b-domik:title'     : 'Вхід',
    'b-domik:login'     : 'логін',
    'b-domik:password'  : 'пароль',
    'b-domik:permanent' : 'запам\'ятати мене',
    'b-domik:help'      : 'що це',
    'b-domik:logon'     : 'Увійти',
    'b-domik:cancel'    : 'Скасувати',
    'b-domik:register'  : 'Зареєструватися',
    'b-domik:remember'  : 'Нагадати пароль',
    'b-domik:enter-with'  : 'Увійти за допомогою',
    'b-domik:wrong-keyboard-layout'  : 'змініть розкладку',

    'b-domik.lock-balloon:content': 'Логін і пароль передаватимуться в&#160;((безпечному режимі))',

    'b-head-userinfo.user:change-password' : 'Змінити пароль',
    'b-head-userinfo.user:profile': 'Мої профілі',

    'b-suggest.hah:on': 'Мої запити ((увімкнено))',
    'b-suggest.hah:off': 'Мої запити ((вимкнено))',
    'b-suggest.hah:linkHref': 'http://tune.yandex.ua/suggest/'
};

})(window.Lego);
