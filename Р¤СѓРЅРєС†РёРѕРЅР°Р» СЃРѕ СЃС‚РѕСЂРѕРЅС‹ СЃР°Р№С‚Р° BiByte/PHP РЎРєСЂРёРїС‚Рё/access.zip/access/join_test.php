<?
	include "GCrypt.php";
	$crypt = new GCrypt();
	$inputmsg = 'Hello world!';
	echo $inputmsg.'</br></br></br>';
	$encodedmsg = $crypt->encode($inputmsg,'Finished:');
	echo $encodedmsg.'</br></br></br>';
	$seed = $crypt->getSeed();
	echo $seed.'</br></br></br>';
	$decodedmsg = $crypt->decode(base64_decode(base64_encode($encodedmsg)), 'Finished:');
	echo $decodedmsg.'</br></br></br>';
	unset($crypt);
?>