<?
require_once "GCrypt.php";
class GBProtocol
{
    private function getFirstAnswerPart($errorCode, $paramCount)
        {
           // Error code 2 byte
           $result = '';
           if(strlen($errorCode)==1) $result = '0';
           $result = $result.$errorCode;
           $crypt = new GCrypt();
           $crypt->init();
           // Garbage 3 byte
           $result = $result.$crypt->randomKey(3); 
           // Count of parameters
           if(strlen($paramCount)==1) $result = $result.'0';
           $result = $result.$paramCount;
           // Garbage 2 byte
           $result = $result.$crypt->randomKey(2); 
           unset($crypt);
           return $result;
        }
 
    public function makeErrorAnswer($errorCode)
	{
	   $result = $this->getFirstAnswerPart($errorCode, 0);	
           return $result;
	}
	
    public function makeAnswer($data)
	{
	   $crypt = new GCrypt();
           $crypt->init();
	   $result = $this->getFirstAnswerPart(0, count($data));	
	   foreach($data as $ability => $isBlocked)
	   {
	   	if(strlen($ability)==1) $result = $result.'0';
	   	$result = $result.$ability.$crypt->randomKey(1).$isBlocked.$crypt->randomKey(1);
	   }
	   unset($crypt);
           return $result;
	}

    public function createMessage($msg, $key)
        {
           $crypt = new GCrypt();
           $encodedResult = $crypt->encode($msg,$key);
           unset($crypt);
           return bin2hex($encodedResult);
           //return unpack("H*" , $encodedResult);
        }

};
?>