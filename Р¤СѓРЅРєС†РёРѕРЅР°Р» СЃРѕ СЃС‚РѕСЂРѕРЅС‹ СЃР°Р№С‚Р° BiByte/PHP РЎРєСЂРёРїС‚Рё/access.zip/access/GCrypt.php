<?
class GCrypt
{
    private $x = 0;
    private $y = 0;
    private $z = 0;
    private $w = 0; // 481301052013 // 88675123
    private $seed = '';
	
    private function randInt($a, $b)
	{ //echo $this->x.' - '.$this->y.' - '.$this->z.' - '.$this->w.'</br>';
                while($this->w > 999999999) $this->w = floor($this->w/10);
		$t = $this->x ^ ($this->x << 11);
		$this->x = $this->y; $this->y = $this->z; $this->z = $this->w;
		$this->w = $this->w ^ ($this->w >> 19) ^ ($t ^ ($t >> 8));
		return ($this->w % (($b + 1) - $a) + $a);
	}

    public function randomKey($lenght)
	{
		$result='';
		for($i=0;$i<$lenght;$i++) $result = $result.chr($this->randInt(48,122));
if($lenght==100) echo '<---';
else echo '--->';
		return $result;
	}

    private function resetSeed()
	{
		// get seed from char seed
		$this->w = 0;
		for($i=0;$i<9;$i++)
		{
			$dec = 1;
			for($j=8;$j > $i;$j--) $dec*=10; 
			$this->w = $this->w + ((ord($this->seed[$i])%10)*$dec);
		}
	}

    public function init($pSeed)
	{
		$this->x = 123456789;
		$this->y = 362436069;
		$this->z = 521288629;
		if($pSeed == '')
		{ // В цьому випадку неправильно генерить сід
			$this->w = intval(date('s'))*100000
                	+ intval(date('i'))*10000
                	+ intval(date('H'))*1000
                	+ intval(date('d'))*100
                	+ intval(date('m'))*10
                	+ intval(date('Y'));
                	
                	$this->seed = '';			
			for($i=0;$i<9;$i++) $this->seed = $this->seed.chr($this->randInt(48,122));
			$this->x = 123456789;
			$this->y = 362436069;
			$this->z = 521288629;
		}else
		{
			$this->seed = strval($pSeed);
		}
		$this->resetSeed();
	}
	
        public function getSeed()
	{
		return $this->seed;
	}

	public function encode($msg, $pSeed = '')
	{
		$this->init($pSeed);
		$result = '';
		$key = $this->randomKey(strlen($msg)); 
		for($i=0;$i<strlen($msg);$i++)
		{
			$result = $result.chr(ord($msg[$i])^ord($key[$i]));
		}
    return $result;
	}

	public function decode($codedmsg, $pSeed)
	{
		$this->init($pSeed);
		$result = '';
		$key = $this->randomKey(strlen($codedmsg));

		for($i=0;$i<strlen($codedmsg);$i++)
		{
			$result = $result.chr(ord($codedmsg[$i])^ord($key[$i]));
		}
		return $result;
	}
};
?>