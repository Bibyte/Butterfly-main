<?
define('DRUPAL_ROOT', $_SERVER['DOCUMENT_ROOT']);
require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
require_once "GBProtocol.php";
require_once "GDataBase.php";
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

   $cryptedMsg = $_GET['req'];
   $crypt = new GCrypt();
   $protocol = new GBProtocol();
   $decoded = pack("H*" , $cryptedMsg);
   $decodedmsg = $crypt->decode($decoded, 'Finished:');

   $protocol_ver = substr($decodedmsg,0,1);
   $login = trim(substr($decodedmsg,4,60));
   $pass = trim(substr($decodedmsg,69,60));
   $mac = substr($decodedmsg,140,12);
   $key = substr($decodedmsg,155,9);
 
   if (module_exists('user')) 
   {	
   	global $user;
   	$uid = user_authenticate($login,$pass);
        if($uid)
        {
        	$arr = array ('name'=>$login,'pass'=>$pass);
  		$user = user_load($uid);
    		user_login_finalize($arr);
      		$db = new GDataBase();
      		if($db->isUserBlocked($login))
      		{
      			echo $protocol->createMessage($protocol->makeErrorAnswer(2),$key); // Помилка: Користувач заблокований
      		}
      		elseif(!$db->haveUserMAC($login,$mac))
      		{              	
      			$crypt->init(); 
      			$emailNotifierKey = bin2hex($crypt->randomKey(100)); 
      			$db_reply = $db->makeMACWait($login,$mac,$emailNotifierKey);
      			if($db_reply)
      			{
      				// Згенерити відправку листа
      				$msg = "Вам пришло уведомление, что Вы пытаетесь использовать Butterfly на другом компьютере.\nЕсли вы действительно хотите использовать программу на другом компьютере, пройдите по ссылке: \n \n";
      				$msg = $msg."http://www.bibyte.net/page/butterfly-confirm-new-comp?req=".$db_reply['key'];
      				$msg = $msg."\n \nЕсли Вы не пытались запустить программу на другом компьютере - проигнорируйте данное письмо.";
      				$msg = $msg."\nСсылка будет доступна до ".$db_reply['actual']." включительно.";
      				$msg = $msg;
      				mail($user->mail, "Butterfly: Подтверждение использования нового компьютера", $msg, "Content-type: text/plain; charset=utf-8; From: noreply@bibyte.net", "-fnoreply@bibyte.net");
      			}
      			else
      			{
      				// отправлять другой код?
      			}
      			echo $protocol->createMessage($protocol->makeErrorAnswer(3),$key); // Помилка: Мак адреса користувача не підтверджена
      		}
      		else
      		{
      			$userAbility = $db->getUserAbility($login);
      			echo $protocol->createMessage($protocol->makeAnswer($userAbility),$key);
      		} 
      }
      else
      {
         echo $protocol->createMessage($protocol->makeErrorAnswer(1),$key); // Помилка: Користувач не зареєстрований
      }
   }
    else
   {
      echo $protocol->createMessage($protocol->makeErrorAnswer(4),$key); // Помилка цього скрипта Drupal
   }

   unset($crypt);
   unset($protocol);
   unset($db);
?>