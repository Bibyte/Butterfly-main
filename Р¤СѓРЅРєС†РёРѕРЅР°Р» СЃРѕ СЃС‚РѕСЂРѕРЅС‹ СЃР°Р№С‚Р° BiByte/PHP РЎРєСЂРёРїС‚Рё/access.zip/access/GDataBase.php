<?

class GDataBase
{
    public function isUserBlocked($userName)
        {
        	require "config.php";
        	$conn = mysql_connect($CONFIG['msql']['host'], $CONFIG['msql']['login'], $CONFIG['msql']['password']) or die(mysql_error());
        	@mysql_select_db($CONFIG['msql']['db'], $conn);
		$result = mysql_query('SELECT * FROM user_block WHERE user="'.$userName.'"');
		if($row = mysql_fetch_object($result))
		{
			mysql_close($conn);
			return $row->isBlocked;
		}
		else
		{
      			mysql_query("INSERT INTO `user_block`(`user`, `isBlocked`) VALUES ('".$userName."',0)");
      			mysql_close($conn);
      			return 0;
		};
		mysql_close($conn);
           	return 0;
        }   

    public function haveUserMAC($userName, $MAC)
        {
        	require "config.php";
        	$conn = mysql_connect($CONFIG['msql']['host'], $CONFIG['msql']['login'], $CONFIG['msql']['password']) or die(mysql_error());
        	@mysql_select_db($CONFIG['msql']['db'], $conn);
        	$result = mysql_query('SELECT * FROM user_macs WHERE user="'.$userName.'"');
		if($row = mysql_fetch_object($result))
		{    // Якщо хоч що небудь знайдено    
        
			$result = mysql_query('SELECT * FROM user_macs WHERE user="'.$userName.'" AND mac="'.$MAC.'"');
			if($row = mysql_fetch_object($result))
			{
				mysql_close($conn);
				return 1;
			}
			else
			{
      				// Нужно добавить новый мак через емейл
      				mysql_close($conn);
      				return 0;
			};
		}
		else
		{ // Якщо в користувача жодної мак адреси
      			mysql_query("INSERT INTO `user_macs`(`user`, `mac`) VALUES ('".$userName."','".$MAC."')");
      			mysql_close($conn);
      			return 1;			
		};
		mysql_close($conn);
           	return 0;
        } 


    public function getUserAbility($userName)
        {
        	require "config.php";
        	$conn = mysql_connect($CONFIG['msql']['host'], $CONFIG['msql']['login'], $CONFIG['msql']['password']) or die(mysql_error());
        	@mysql_select_db($CONFIG['msql']['db'], $conn);
        	$result = mysql_query('SELECT * FROM user_ability WHERE user="'.$userName.'"');
		while($row = mysql_fetch_object($result))
		{
			 $ret_res[$row->ability] = $row->isBlocked;  
		}    
		mysql_close($conn);     
           	return $ret_res;
        } 
        
	public function makeMACWait($userName,$mac,$emailNotifierKey)   
    	{
        	require "config.php";
        	$conn = mysql_connect($CONFIG['msql']['host'], $CONFIG['msql']['login'], $CONFIG['msql']['password']) or die(mysql_error());
        	@mysql_select_db($CONFIG['msql']['db'], $conn);
        	// Удаляємо старі записи, тіпа Крон :)))
        	//$currDate = date('Y-m-d H:i:s', strtotime('-30 minutes')); //2592000; // Поточна дата - місяць
        	$currDate = date('Y-m-d H:i:s'); // Поточна дата
        	$result = mysql_query('DELETE FROM user_mac_wait WHERE actual < "'.$currDate.'"'); 
        	// Перевіряєм чи такий запис вже є
        	$currDate = date('Y-m-d H:i:s'); // Поточна дата
        	$result = mysql_query('SELECT * FROM user_mac_wait WHERE user="'.$userName.'" AND mac="'.$mac.'" AND actual >= "'.$currDate.'"');  
        	if($row = mysql_fetch_object($result)) // Якщо вже такий логін і мак є то просто повертаєм їх дату актуальності і все
		{
			//$result['key'] = $row->key;
			//$result['actual'] = $row->actual;
			mysql_close($conn);
			//return $result;
			return 0; // Не треба ще раз емейл відсилати
		} 
		// Перевіримо ключ на унікальність
		$result = mysql_query('SELECT user FROM user_mac_wait WHERE key="'.$emailNotifierKey.'"');
		while($row = mysql_fetch_object($result)) 
		{
			if(strlen($emailNotifierKey)==200)
			{
				mysql_close($conn);
				return 0;
			}
			$emailNotifierKey = $emailNotifierKey.chr(rand(48,57));
			$result = mysql_query('SELECT user FROM user_mac_wait WHERE key="'.$emailNotifierKey.'"');
		}
		// Ключ унікальний, додаєм
		$currDate = date('Y-m-d H:i:s', strtotime('+30 minutes')); //259200; // + 3 дня
		mysql_query("INSERT INTO `user_mac_wait`(`user`, `mac`, `key`, `actual`) 
		VALUES ('".$userName."','".$mac."','".$emailNotifierKey."','".$currDate."')");
		
		$result['key'] = $emailNotifierKey;
		$result['actual'] = $currDate;
		mysql_close($conn);
		return $result;
			    
    	}
    
    	public function useMACWait($emailNotifierKey)   
    	{
    	       	require "config.php";
        	$conn = mysql_connect($CONFIG['msql']['host'], $CONFIG['msql']['login'], $CONFIG['msql']['password']) or die(mysql_error());
        	@mysql_select_db($CONFIG['msql']['db'], $conn);
        	$currDate = date('Y-m-d H:i:s');
    		$result = mysql_query('SELECT * FROM user_mac_wait WHERE user_mac_wait.key = "'.$emailNotifierKey.'" AND user_mac_wait.actual >= "'.$currDate.'"');

		if($row = mysql_fetch_object($result)) 
		{
			mysql_query("INSERT INTO `user_macs`(`user`, `mac`) VALUES ('".$row->user."','".$row->mac."')");
			mysql_query('DELETE FROM user_mac_wait WHERE user_mac_wait.key="'.$emailNotifierKey.'"');
			mysql_close($conn);
			return 1;	
		}
		mysql_close($conn);
		return 0;
    	}
};
?>